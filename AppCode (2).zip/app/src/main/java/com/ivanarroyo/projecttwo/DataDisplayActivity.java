package com.ivanarroyo.projecttwo;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;


public class DataDisplayActivity extends AppCompatActivity {
    private GridView gridData;
    private Button btnAddData;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        gridData = findViewById(R.id.grid_data);
        btnAddData = findViewById(R.id.btn_add_data);
        Button btnSmsNotification = findViewById(R.id.btn_sms_notification); // New Button

        // Initializes the database connection
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        db = dbHelper.getWritableDatabase();

        // Adds initial data for testing
        db.execSQL("CREATE TABLE IF NOT EXISTS Items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, quantity INTEGER)");
        if (getRowCount() == 0) { // Check if table is empty
            db.execSQL("INSERT INTO Items (name, quantity) VALUES ('Sample Item', 10)");
        }

        loadGridData();

        btnAddData.setOnClickListener(v -> {
            try {
                db.execSQL("INSERT INTO Items (name, quantity) VALUES ('New Item', 1)");
                loadGridData();
                Toast.makeText(this, "Item Added!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Log.e("DataDisplayActivity", "Error adding item: " + e.getMessage());
                Toast.makeText(this, "Error adding item: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        btnSmsNotification.setOnClickListener(v -> {
            Intent intent = new Intent(DataDisplayActivity.this, SMSNotificationActivity.class);
            startActivity(intent);
        });
    }

    private void loadGridData() {
        ArrayList<String> data = new ArrayList<>();
        try (Cursor cursor = db.query("Items", null, null, null, null, null, null)) {
            int nameIndex = cursor.getColumnIndex("name");
            int quantityIndex = cursor.getColumnIndex("quantity");

            // Checks if column indices are valid
            if (nameIndex == -1 || quantityIndex == -1) {
                Log.e("DataDisplayActivity", "Invalid column index: Check database schema.");
                Toast.makeText(this, "Database columns are missing!", Toast.LENGTH_SHORT).show();
                return;
            }

            while (cursor.moveToNext()) {
                String name = cursor.getString(nameIndex);
                int quantity = cursor.getInt(quantityIndex);
                data.add(name + " - " + quantity);
            }
            Log.d("DataDisplayActivity", "Data loaded successfully. Data size: " + data.size());
        } catch (Exception e) {
            Log.e("DataDisplayActivity", "Error loading data: " + e.getMessage());
            Toast.makeText(this, "Error loading data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            return;
        }

        GridViewAdapter adapter = new GridViewAdapter(this, data);
        gridData.setAdapter(adapter);
    }

    private int getRowCount() {
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM Items", null);
        int count = 0;
        if (cursor.moveToFirst()) {
            count = cursor.getInt(0);
        }
        cursor.close();
        return count;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (db != null && db.isOpen()) {
            db.close();
        }
    }
}
